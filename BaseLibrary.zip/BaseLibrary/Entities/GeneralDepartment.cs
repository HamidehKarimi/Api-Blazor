﻿namespace BaseLibrary.Entities
{
    public class GeneralDepartment : BaseEntity
    {
    }
}
