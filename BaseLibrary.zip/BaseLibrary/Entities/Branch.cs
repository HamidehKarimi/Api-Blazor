﻿namespace BaseLibrary.Entities
{
    public class Branch : BaseEntity
    {
    }
}
