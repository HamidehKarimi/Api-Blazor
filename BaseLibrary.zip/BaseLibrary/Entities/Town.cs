﻿namespace BaseLibrary.Entities
{
    public class Town : BaseEntity
    {
    }
}
