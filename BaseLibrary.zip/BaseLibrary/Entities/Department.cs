﻿namespace BaseLibrary.Entities
{
    public class Department : BaseEntity 
    {
    }
}
