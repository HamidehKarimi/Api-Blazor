﻿namespace BaseLibrary.DTOs
{
    public class UseSession
    {
        public string? Token { get; set; }
        public string? RefreshToken { get; set; }
    }
}
