﻿namespace BaseLibrary.DTOs
{
    public class Login : AccountBase
    {
    }
}
